export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };
export type AiResult = { ok: true; text: string } | { ok: false; error: string; needsKey?: boolean };

const MODELS = [
  "gemini-3.5-flash",
  "gemini-3.7-flash",
  "gemini-3.6-flash",
  "gemini-flash-latest",
  "gemini-3-flash-preview",
  "gemini-3.5-flash-lite",
];

let cachedModel: string | null = null;

export function sanitizeGeminiKey(raw: string): string {
  return raw
    .trim()
    .replace(/^['"`]+|['"`]+$/g, "")
    .replace(/^Bearer\s+/i, "")
    .replace(/^(?:GEMINI_API_KEY|GOOGLE_API_KEY|API_KEY)\s*=\s*/i, "")
    .trim();
}

function googleMessage(json: unknown): string {
  if (Array.isArray(json) && json[0] && typeof json[0] === "object") {
    const err = (json[0] as { error?: { message?: string } }).error;
    if (typeof err?.message === "string") return err.message.replace(/\s+/g, " ").trim();
  }
  if (json && typeof json === "object") {
    const err = (json as { error?: { message?: string } }).error;
    if (typeof err?.message === "string") return err.message.replace(/\s+/g, " ").trim();
  }
  return "";
}

function isInvalidKey(status: number, message: string): boolean {
  if (status === 401 || status === 403) return true;
  return /api[_ ]key|invalid api key|permission|unregistered|caller|not valid/i.test(message);
}

function invalidKeyResult(): AiResult {
  return {
    ok: false,
    error: "Gemini API 金鑰無效。請到 Google AI Studio 重新複製完整金鑰（通常以 AIza 開頭）。",
    needsKey: true,
  };
}

async function readJson(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

async function tryOpenAI(
  apiKey: string,
  model: string,
  messages: ChatMessage[],
  maxTokens: number,
): Promise<{ status: number; json: unknown }> {
  const res = await fetch("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      max_tokens: Math.max(256, maxTokens),
      temperature: 0.4,
    }),
    signal: AbortSignal.timeout(28000),
  });
  return { status: res.status, json: await readJson(res) };
}

function toNativeContents(messages: ChatMessage[]): {
  system: string;
  contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }>;
} {
  const system = messages
    .filter((item) => item.role === "system")
    .map((item) => item.content)
    .join("\n");
  const contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];
  for (const item of messages) {
    if (item.role === "system") continue;
    const role = item.role === "assistant" ? "model" : "user";
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += `\n${item.content}`;
    else contents.push({ role, parts: [{ text: item.content }] });
  }
  if (contents.length === 0) contents.push({ role: "user", parts: [{ text: "請開始。" }] });
  else if (contents[0].role === "model") contents.unshift({ role: "user", parts: [{ text: "請開始。" }] });
  return { system, contents };
}

async function tryNative(
  apiKey: string,
  model: string,
  messages: ChatMessage[],
  maxTokens: number,
): Promise<{ status: number; json: unknown }> {
  const { system, contents } = toNativeContents(messages);
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents,
        generationConfig: { maxOutputTokens: Math.max(256, maxTokens), temperature: 0.4 },
        ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
      }),
      signal: AbortSignal.timeout(28000),
    },
  );
  return { status: res.status, json: await readJson(res) };
}

function readOpenAIText(json: unknown): string {
  if (!json || typeof json !== "object") return "";
  const choices = (json as { choices?: Array<{ message?: { content?: string } }> }).choices;
  return choices?.[0]?.message?.content?.trim() ?? "";
}

function readNativeText(json: unknown): string {
  if (!json || typeof json !== "object") return "";
  const candidates = (json as { candidates?: Array<{ finishReason?: string; content?: { parts?: Array<{ text?: string }> } }> }).candidates;
  const first = candidates?.[0];
  if (!first || first.finishReason === "SAFETY") return "";
  return first.content?.parts?.map((part) => part.text ?? "").join("").trim() ?? "";
}

export async function completeGemini(apiKey: string, messages: ChatMessage[], maxTokens: number): Promise<AiResult> {
  const key = sanitizeGeminiKey(apiKey);
  if (!key) {
    return { ok: false, error: "尚未貼上 Gemini API 金鑰。", needsKey: true };
  }

  const models = [...new Set([cachedModel, ...MODELS].filter((item): item is string => Boolean(item)))];
  let lastMessage = "";
  let lastStatus = 0;

  try {
    for (const model of models) {
      const openai = await tryOpenAI(key, model, messages, maxTokens);
      lastStatus = openai.status;
      lastMessage = googleMessage(openai.json);
      if (isInvalidKey(openai.status, lastMessage)) return invalidKeyResult();
      if (openai.status === 429) return { ok: false, error: "Gemini 用量已滿，請稍後再試。" };
      if (openai.status >= 200 && openai.status < 300) {
        const text = readOpenAIText(openai.json);
        if (text) {
          cachedModel = model;
          return { ok: true, text };
        }
      }

      const native = await tryNative(key, model, messages, maxTokens);
      lastStatus = native.status;
      lastMessage = googleMessage(native.json);
      if (isInvalidKey(native.status, lastMessage)) return invalidKeyResult();
      if (native.status === 429) return { ok: false, error: "Gemini 用量已滿，請稍後再試。" };
      if (native.status >= 200 && native.status < 300) {
        const text = readNativeText(native.json);
        if (text) {
          cachedModel = model;
          return { ok: true, text };
        }
        return { ok: false, error: "AI 沒有回傳內容。" };
      }
    }

    return {
      ok: false,
      error: lastMessage
        ? `Gemini 連線失敗（${lastStatus}）：${lastMessage.slice(0, 180)}`
        : "無法連上 Gemini。請確認金鑰來自 aistudio.google.com/apikey。",
      needsKey: lastStatus === 404 || lastStatus === 400,
    };
  } catch {
    return { ok: false, error: "連線逾時或被瀏覽器攔截，請再試一次。" };
  }
}

export async function pingGemini(apiKey: string): Promise<AiResult> {
  return completeGemini(
    apiKey,
    [
      { role: "system", content: "只回兩個字：就緒" },
      { role: "user", content: "測試連線" },
    ],
    32,
  );
}
