import { articles, getArticle } from "@/data/articles";
import { explainQuiz, generateQuiz, gradeDictation, pingAi, tutorChat } from "@/lib/ai";
import { completeGemini, pingGemini, type ChatMessage } from "@/lib/gemini";
import { getGeminiKey, withGeminiKey } from "@/lib/gemini-key";

const TITLES = articles.map((item) => item.title).join("、");

function localKey(): string {
  return getGeminiKey();
}

export async function pingAssistant(geminiKey?: string) {
  const key = (geminiKey ?? localKey()).trim();
  if (key) return pingGemini(key);
  return pingAi({ data: {} });
}

export async function askTutor(input: {
  articleId?: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
}) {
  const key = localKey();
  if (!key) return tutorChat({ data: withGeminiKey(input) });

  const article = input.articleId ? getArticle(input.articleId) : undefined;
  const context = article
    ? [
        `學生正在讀：${article.title}（${article.author}）`,
        `核心論點：${article.c.join("；")}`,
        `必考詞：${article.v.map((item) => `${item.w}＝${item.m}`).join("；")}`,
        `原文節錄：${article.p
          .slice(0, 2)
          .map((para) => para.t)
          .join("")
          .slice(0, 500)}`,
      ].join("\n")
    : `指定範文目錄：${TITLES}`;

  const history = input.messages.slice(-8).map((item) => ({
    role: item.role,
    content: item.content.slice(0, 800),
  }));

  const messages: ChatMessage[] = [
    {
      role: "system",
      content: [
        "你是「範文十二式」書齋助教，專責香港 DSE 中文科十二篇指定範文。",
        "用簡潔繁體中文回答：先一句結論，再短點說明。必要時引用原文短句。",
        "不要編造課外原文，不確定就明說。不要用 emoji，不要長篇作文。",
        context,
      ].join("\n"),
    },
    ...history,
  ];
  return completeGemini(key, messages, 420);
}

export async function askExplain(input: {
  articleTitle: string;
  question: string;
  options: string[];
  correctIndex: number;
  pickedIndex: number;
}) {
  const key = localKey();
  if (!key) return explainQuiz({ data: withGeminiKey(input) });
  const correct = input.options[input.correctIndex] ?? "";
  const picked = input.options[input.pickedIndex] ?? "";
  const wrong = input.pickedIndex !== input.correctIndex;
  return completeGemini(
    key,
    [
      {
        role: "system",
        content:
          "你是香港文憑試中文科助教，只講十二篇指定範文。用簡潔繁體中文（香港用語）作答。先給結論，再分點解釋。不要使用英文，不要用 emoji。",
      },
      {
        role: "user",
        content: [
          `篇章：${input.articleTitle}`,
          `題目：${input.question}`,
          `選項：${input.options.map((opt, i) => `${i + 1}. ${opt}`).join("／")}`,
          `學生選了：${picked}`,
          `正確答案：${correct}`,
          wrong
            ? "請說明為何學生所選是錯的、正確選項為何對，並補一句相關原文或詞義提醒。120 字內。"
            : "學生答對了。請用兩句話鞏固這個考點，並補一句易混點。100 字內。",
        ].join("\n"),
      },
    ],
    280,
  );
}

export async function askGrade(input: {
  articleTitle: string;
  sentence: string;
  expected: string[];
  given: string[];
}) {
  const key = localKey();
  if (!key) return gradeDictation({ data: withGeminiKey(input) });
  return completeGemini(
    key,
    [
      {
        role: "system",
        content:
          "你是文憑試中文默書助教。用繁體中文。允許通假字、異體字的彈性，但關鍵實詞寫錯仍要指出。不要用 emoji。",
      },
      {
        role: "user",
        content: [
          `篇章：${input.articleTitle}`,
          `原句：${input.sentence}`,
          `應填：${input.expected.join("、")}`,
          `學生：${input.given.map((item) => item || "（空白）").join("、")}`,
          "請用這種格式回覆：",
          "判定：全對／語意對用字有誤／錯誤",
          "評語：兩句以內，指出哪個字錯、正確寫法、以及這個詞在句中的意思。",
        ].join("\n"),
      },
    ],
    220,
  );
}

export async function askGenerateQuiz(articleId: string) {
  const key = localKey();
  if (!key) return generateQuiz({ data: withGeminiKey({ articleId }) });

  const article = getArticle(articleId);
  if (!article) return { ok: false as const, error: "找不到這篇範文。" };

  const excerpt = article.p
    .map((para) => para.t)
    .join("\n")
    .slice(0, 1400);

  const result = await completeGemini(
    key,
    [
      {
        role: "system",
        content: "你是 DSE 中文科出題老師。只根據提供的指定範文出題。回覆必須是純 JSON 陣列，不要 markdown。",
      },
      {
        role: "user",
        content: [
          `篇章：${article.title}／${article.author}`,
          `論點：${article.c.join("；")}`,
          `詞解：${article.v.map((item) => `${item.w}：${item.m}`).join("；")}`,
          `原文：${excerpt}`,
          "請出 6 題四選一選擇題，覆蓋：詞義、句意、寫作手法、主旨。難度接近 HKDSE。",
          '格式：[{"q":"題幹","o":["A","B","C","D"],"a":0}]',
          "a 是正確選項的 0-based 索引。題幹與選項用繁體中文。",
        ].join("\n"),
      },
    ],
    900,
  );
  if (!result.ok) return result;

  try {
    const fenced = result.text.match(/```(?:json)?\s*([\s\S]*?)```/);
    const raw = fenced ? fenced[1] : result.text;
    const start = raw.indexOf("[");
    const end = raw.lastIndexOf("]");
    if (start < 0 || end <= start) return { ok: false as const, error: "AI 回傳格式不正確。" };
    const parsed = JSON.parse(raw.slice(start, end + 1)) as unknown;
    if (!Array.isArray(parsed)) return { ok: false as const, error: "AI 回傳格式不正確。" };
    const questions = parsed
      .map((row) => {
        if (!row || typeof row !== "object") return null;
        const item = row as { q?: unknown; o?: unknown; a?: unknown };
        if (typeof item.q !== "string" || !Array.isArray(item.o) || typeof item.a !== "number") return null;
        const options = item.o.filter((opt): opt is string => typeof opt === "string").slice(0, 4);
        if (options.length < 4) return null;
        const answer = Math.max(0, Math.min(3, Math.round(item.a)));
        return { q: item.q.trim(), o: options, a: answer };
      })
      .filter((item): item is { q: string; o: string[]; a: number } => Boolean(item))
      .slice(0, 6);
    if (questions.length < 4) return { ok: false as const, error: "AI 出題數量不足，請再試一次。" };
    return { ok: true as const, questions };
  } catch {
    return { ok: false as const, error: "無法解析 AI 出題結果。" };
  }
}
