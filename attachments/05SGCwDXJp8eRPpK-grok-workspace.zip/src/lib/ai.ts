import { createServerFn } from "@tanstack/react-start";
import { articles, getArticle } from "@/data/articles";
import { completeGemini } from "@/lib/gemini";

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

type AiFail = { ok: false; error: string; needsKey?: boolean };
type AiOk = { ok: true; text: string };
type AiResult = AiOk | AiFail;

type Keyed = { geminiKey?: string };

type ExplainInput = Keyed & {
  articleTitle: string;
  question: string;
  options: string[];
  correctIndex: number;
  pickedIndex: number;
};

type GradeInput = Keyed & {
  articleTitle: string;
  sentence: string;
  expected: string[];
  given: string[];
};

type TutorInput = Keyed & {
  articleId?: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
};

type GenerateInput = Keyed & {
  articleId: string;
};

const TITLES = articles.map((item) => item.title).join("、");
function envGeminiKey(): string {
  return (
    process.env.GEMINI_API_KEY ||
    process.env.GOOGLE_GENERATIVE_AI_API_KEY ||
    process.env.GOOGLE_API_KEY ||
    ""
  ).trim();
}

function resolveProvider(clientKey?: string): { provider: "gemini" | "xai"; key: string } | null {
  const gemini = (clientKey ?? "").trim() || envGeminiKey();
  if (gemini) return { provider: "gemini", key: gemini };
  const xai = (process.env.XAI_API_KEY ?? "").trim();
  if (xai) return { provider: "xai", key: xai };
  return null;
}

async function completeXai(apiKey: string, messages: ChatMessage[], maxTokens: number): Promise<AiResult> {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      max_tokens: maxTokens,
      temperature: 0.4,
    }),
    signal: AbortSignal.timeout(28000),
  });
  if (!res.ok) {
    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        error: "備用引擎未能連線。請在設定中貼上 Gemini API 金鑰。",
        needsKey: true,
      };
    }
    return { ok: false, error: "AI 服務忙碌，請稍後再試。" };
  }
  const body = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = body.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) return { ok: false, error: "AI 沒有回傳內容。" };
  return { ok: true, text };
}

async function complete(messages: ChatMessage[], maxTokens: number, clientKey?: string): Promise<AiResult> {
  const resolved = resolveProvider(clientKey);
  if (!resolved) {
    return {
      ok: false,
      error: "尚未設定 Gemini API 金鑰。請在助教面板貼上金鑰，或於網站後台加入 GEMINI_API_KEY。",
      needsKey: true,
    };
  }
  try {
    if (resolved.provider === "gemini") return await completeGemini(resolved.key, messages, maxTokens);
    return await completeXai(resolved.key, messages, maxTokens);
  } catch {
    return { ok: false, error: "連線逾時，請稍後再試。" };
  }
}

export const aiStatus = createServerFn({ method: "GET" }).handler(async () => {
  return {
    geminiEnv: Boolean(envGeminiKey()),
    xaiEnv: Boolean((process.env.XAI_API_KEY ?? "").trim()),
  };
});

export const pingAi = createServerFn({ method: "POST" })
  .validator((input: Keyed) => input)
  .handler(async ({ data }) => {
    return complete(
      [
        { role: "system", content: "只回兩個字：就緒" },
        { role: "user", content: "測試連線" },
      ],
      32,
      data.geminiKey,
    );
  });

export const explainQuiz = createServerFn({ method: "POST" })
  .validator((input: ExplainInput) => input)
  .handler(async ({ data }) => {
    const correct = data.options[data.correctIndex] ?? "";
    const picked = data.options[data.pickedIndex] ?? "";
    const wrong = data.pickedIndex !== data.correctIndex;
    return complete(
      [
        {
          role: "system",
          content:
            "你是香港文憑試中文科助教，只講十二篇指定範文。用簡潔繁體中文（香港用語）作答。先給結論，再分點解釋。不要使用英文，不要用 emoji。",
        },
        {
          role: "user",
          content: [
            `篇章：${data.articleTitle}`,
            `題目：${data.question}`,
            `選項：${data.options.map((opt, i) => `${i + 1}. ${opt}`).join("／")}`,
            `學生選了：${picked}`,
            `正確答案：${correct}`,
            wrong
              ? "請說明為何學生所選是錯的、正確選項為何對，並補一句相關原文或詞義提醒。120 字內。"
              : "學生答對了。請用兩句話鞏固這個考點，並補一句易混點。100 字內。",
          ].join("\n"),
        },
      ],
      280,
      data.geminiKey,
    );
  });

export const gradeDictation = createServerFn({ method: "POST" })
  .validator((input: GradeInput) => input)
  .handler(async ({ data }) => {
    return complete(
      [
        {
          role: "system",
          content:
            "你是文憑試中文默書助教。用繁體中文。允許通假字、異體字的彈性，但關鍵實詞寫錯仍要指出。不要用 emoji。",
        },
        {
          role: "user",
          content: [
            `篇章：${data.articleTitle}`,
            `原句：${data.sentence}`,
            `應填：${data.expected.join("、")}`,
            `學生：${data.given.map((item) => item || "（空白）").join("、")}`,
            "請用這種格式回覆：",
            "判定：全對／語意對用字有誤／錯誤",
            "評語：兩句以內，指出哪個字錯、正確寫法、以及這個詞在句中的意思。",
          ].join("\n"),
        },
      ],
      220,
      data.geminiKey,
    );
  });

export const tutorChat = createServerFn({ method: "POST" })
  .validator((input: TutorInput) => input)
  .handler(async ({ data }) => {
    const article = data.articleId ? getArticle(data.articleId) : undefined;
    const context = article
      ? [
          `學生正在讀：${article.title}（${article.author}）`,
          `核心論點：${article.c.join("；")}`,
          `必考詞：${article.v.map((item) => `${item.w}＝${item.m}`).join("；")}`,
          `原文節錄：${article.p
            .slice(0, 2)
            .map((para) => para.t)
            .join("")
            .slice(0, 500)}`,
        ].join("\n")
      : `指定範文目錄：${TITLES}`;

    const history = data.messages.slice(-8).map((item) => ({
      role: item.role,
      content: item.content.slice(0, 800),
    }));

    return complete(
      [
        {
          role: "system",
          content: [
            "你是「範文十二式」書齋助教，專責香港 DSE 中文科十二篇指定範文。",
            "用簡潔繁體中文回答：先一句結論，再短點說明。必要時引用原文短句。",
            "不要編造課外原文，不確定就明說。不要用 emoji，不要長篇作文。",
            context,
          ].join("\n"),
        },
        ...history,
      ],
      420,
      data.geminiKey,
    );
  });

export const generateQuiz = createServerFn({ method: "POST" })
  .validator((input: GenerateInput) => input)
  .handler(async ({ data }) => {
    const article = getArticle(data.articleId);
    if (!article) return { ok: false as const, error: "找不到這篇範文。" };

    const excerpt = article.p
      .map((para) => para.t)
      .join("\n")
      .slice(0, 1400);

    const result = await complete(
      [
        {
          role: "system",
          content:
            "你是 DSE 中文科出題老師。只根據提供的指定範文出題。回覆必須是純 JSON 陣列，不要 markdown。",
        },
        {
          role: "user",
          content: [
            `篇章：${article.title}／${article.author}`,
            `論點：${article.c.join("；")}`,
            `詞解：${article.v.map((item) => `${item.w}：${item.m}`).join("；")}`,
            `原文：${excerpt}`,
            "請出 6 題四選一選擇題，覆蓋：詞義、句意、寫作手法、主旨。難度接近 HKDSE。",
            '格式：[{"q":"題幹","o":["A","B","C","D"],"a":0}]',
            "a 是正確選項的 0-based 索引。題幹與選項用繁體中文。",
          ].join("\n"),
        },
      ],
      900,
      data.geminiKey,
    );

    if (!result.ok) return result;

    try {
      const fenced = result.text.match(/```(?:json)?\s*([\s\S]*?)```/);
      const raw = fenced ? fenced[1] : result.text;
      const start = raw.indexOf("[");
      const end = raw.lastIndexOf("]");
      if (start < 0 || end <= start) return { ok: false as const, error: "AI 回傳格式不正確。" };
      const parsed = JSON.parse(raw.slice(start, end + 1)) as unknown;
      if (!Array.isArray(parsed)) return { ok: false as const, error: "AI 回傳格式不正確。" };
      const questions = parsed
        .map((row) => {
          if (!row || typeof row !== "object") return null;
          const item = row as { q?: unknown; o?: unknown; a?: unknown };
          if (typeof item.q !== "string" || !Array.isArray(item.o) || typeof item.a !== "number") return null;
          const options = item.o.filter((opt): opt is string => typeof opt === "string").slice(0, 4);
          if (options.length < 4) return null;
          const answer = Math.max(0, Math.min(3, Math.round(item.a)));
          return { q: item.q.trim(), o: options, a: answer };
        })
        .filter((item): item is { q: string; o: string[]; a: number } => Boolean(item))
        .slice(0, 6);
      if (questions.length < 4) return { ok: false as const, error: "AI 出題數量不足，請再試一次。" };
      return { ok: true as const, questions };
    } catch {
      return { ok: false as const, error: "無法解析 AI 出題結果。" };
    }
  });
