//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlX0C9fT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/dictation",
			"/games",
			"/quiz",
			"/read/$id"
		],
		preloads: [
			"/assets/index-CY_MIPXb.js",
			"/assets/useStore-CP8wJgJA.js",
			"/assets/articles-DEe0qkJP.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/matchContext-D_yddPR9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CY_MIPXb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D3IIQJfD.js",
			"/assets/timer-DhYmrWHI.js",
			"/assets/arrow-right-B6osF4Vb.js",
			"/assets/sparkles-z6tCWVkh.js"
		]
	},
	"/dictation": {
		filePath: "/workspace/src/routes/dictation.tsx",
		children: void 0,
		preloads: [
			"/assets/dictation-DJFoAKEL.js",
			"/assets/arrow-right-B6osF4Vb.js",
			"/assets/check-D0YJcXvN.js",
			"/assets/circle-x-Ce44uQLf.js",
			"/assets/AiExplain-DNu2iIuw.js"
		]
	},
	"/games": {
		filePath: "/workspace/src/routes/games.tsx",
		children: [
			"/games/hangman",
			"/games/match",
			"/games/snake",
			"/games/sort",
			"/games/time",
			"/games/"
		],
		preloads: ["/assets/games-CZ8D6Dgy.js"]
	},
	"/quiz": {
		filePath: "/workspace/src/routes/quiz.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz-DDBZi2sZ.js",
			"/assets/circle-x-Ce44uQLf.js",
			"/assets/rotate-ccw-YNWTZ4SM.js",
			"/assets/sparkles-z6tCWVkh.js",
			"/assets/AiExplain-DNu2iIuw.js"
		]
	},
	"/games/hangman": {
		filePath: "/workspace/src/routes/games.hangman.tsx",
		children: void 0,
		preloads: [
			"/assets/games.hangman-C7aqRrT-.js",
			"/assets/heart-BxowD7Sq.js",
			"/assets/sfx-C_vQT-dv.js"
		]
	},
	"/games/match": {
		filePath: "/workspace/src/routes/games.match.tsx",
		children: void 0,
		preloads: ["/assets/games.match-LjEUKIPN.js", "/assets/sfx-C_vQT-dv.js"]
	},
	"/games/snake": {
		filePath: "/workspace/src/routes/games.snake.tsx",
		children: void 0,
		preloads: [
			"/assets/games.snake-BVW_lran.js",
			"/assets/heart-BxowD7Sq.js",
			"/assets/sfx-C_vQT-dv.js"
		]
	},
	"/games/sort": {
		filePath: "/workspace/src/routes/games.sort.tsx",
		children: void 0,
		preloads: [
			"/assets/games.sort-lMJVQYUC.js",
			"/assets/check-D0YJcXvN.js",
			"/assets/sfx-C_vQT-dv.js",
			"/assets/rotate-ccw-YNWTZ4SM.js"
		]
	},
	"/games/time": {
		filePath: "/workspace/src/routes/games.time.tsx",
		children: void 0,
		preloads: [
			"/assets/games.time-B-zj9_yD.js",
			"/assets/circle-x-Ce44uQLf.js",
			"/assets/sfx-C_vQT-dv.js"
		]
	},
	"/read/$id": {
		filePath: "/workspace/src/routes/read.$id.tsx",
		children: void 0,
		preloads: ["/assets/read._id-jCj3S1ex.js", "/assets/arrow-left-Bv-noE7B.js"]
	},
	"/games/": {
		filePath: "/workspace/src/routes/games.index.tsx",
		children: void 0,
		preloads: [
			"/assets/games.index-DoPZ3QIQ.js",
			"/assets/timer-DhYmrWHI.js",
			"/assets/arrow-right-B6osF4Vb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
