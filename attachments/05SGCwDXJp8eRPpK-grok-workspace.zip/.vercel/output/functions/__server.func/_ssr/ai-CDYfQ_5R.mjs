import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { r as getArticle, t as articles } from "./articles-ByMscbRy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-CDYfQ_5R.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var TITLES = articles.map((item) => item.title).join("、");
var GEMINI_MODELS = ["gemini-2.5-flash", "gemini-2.0-flash"];
function envGeminiKey() {
	return (process.env.GEMINI_API_KEY || process.env.GOOGLE_GENERATIVE_AI_API_KEY || process.env.GOOGLE_API_KEY || "").trim();
}
function resolveProvider(clientKey) {
	const gemini = (clientKey ?? "").trim() || envGeminiKey();
	if (gemini) return {
		provider: "gemini",
		key: gemini
	};
	const xai = (process.env.XAI_API_KEY ?? "").trim();
	if (xai) return {
		provider: "xai",
		key: xai
	};
	return null;
}
function geminiContents(messages) {
	const system = messages.filter((item) => item.role === "system").map((item) => item.content).join("\n");
	const contents = [];
	for (const item of messages) {
		if (item.role === "system") continue;
		const role = item.role === "assistant" ? "model" : "user";
		const last = contents[contents.length - 1];
		if (last && last.role === role) last.parts[0].text += `\n${item.content}`;
		else contents.push({
			role,
			parts: [{ text: item.content }]
		});
	}
	if (contents.length === 0) contents.push({
		role: "user",
		parts: [{ text: "請開始。" }]
	});
	else if (contents[0].role === "model") contents.unshift({
		role: "user",
		parts: [{ text: "請開始。" }]
	});
	return {
		system,
		contents
	};
}
function readGeminiText(body) {
	if (!body || typeof body !== "object") return "";
	const candidates = body.candidates;
	if (!Array.isArray(candidates) || !candidates[0] || typeof candidates[0] !== "object") return "";
	const candidate = candidates[0];
	if (candidate.finishReason === "SAFETY") return "";
	return candidate.content?.parts?.map((part) => part.text ?? "").join("").trim() ?? "";
}
async function completeGemini(apiKey, messages, maxTokens) {
	const { system, contents } = geminiContents(messages);
	const baseBody = {
		contents,
		generationConfig: {
			maxOutputTokens: Math.max(256, maxTokens),
			temperature: .4,
			thinkingConfig: { thinkingBudget: 0 }
		},
		...system ? { systemInstruction: { parts: [{ text: system }] } } : {}
	};
	let lastStatus = 0;
	for (const model of GEMINI_MODELS) {
		const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": apiKey
			},
			body: JSON.stringify(baseBody),
			signal: AbortSignal.timeout(28e3)
		});
		lastStatus = res.status;
		if (res.status === 404) continue;
		if (res.status === 400) {
			const retry = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": apiKey
				},
				body: JSON.stringify({
					contents,
					generationConfig: {
						maxOutputTokens: Math.max(256, maxTokens),
						temperature: .4
					},
					...system ? { systemInstruction: { parts: [{ text: system }] } } : {}
				}),
				signal: AbortSignal.timeout(28e3)
			});
			if (!retry.ok) {
				lastStatus = retry.status;
				if (retry.status === 404) continue;
				if (retry.status === 400 || retry.status === 401 || retry.status === 403) return {
					ok: false,
					error: "Gemini API 金鑰無效或無權限，請重新設定。",
					needsKey: true
				};
				return {
					ok: false,
					error: "AI 服務忙碌，請稍後再試。"
				};
			}
			const text = readGeminiText(await retry.json());
			if (!text) return {
				ok: false,
				error: "AI 沒有回傳內容。"
			};
			return {
				ok: true,
				text
			};
		}
		if (res.status === 400 || res.status === 401 || res.status === 403) return {
			ok: false,
			error: "Gemini API 金鑰無效或無權限，請重新設定。",
			needsKey: true
		};
		if (res.status === 429) return {
			ok: false,
			error: "Gemini 用量已滿，請稍後再試。"
		};
		if (!res.ok) return {
			ok: false,
			error: "AI 服務忙碌，請稍後再試。"
		};
		const text = readGeminiText(await res.json());
		if (!text) return {
			ok: false,
			error: "AI 沒有回傳內容。"
		};
		return {
			ok: true,
			text
		};
	}
	if (lastStatus === 401 || lastStatus === 403) return {
		ok: false,
		error: "Gemini API 金鑰無效或無權限，請重新設定。",
		needsKey: true
	};
	return {
		ok: false,
		error: "找不到可用的 Gemini 模型，請稍後再試。"
	};
}
async function completeXai(apiKey, messages, maxTokens) {
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			messages,
			max_tokens: maxTokens,
			temperature: .4
		}),
		signal: AbortSignal.timeout(28e3)
	});
	if (!res.ok) {
		if (res.status === 401 || res.status === 403) return {
			ok: false,
			error: "備用引擎未能連線。請在設定中貼上 Gemini API 金鑰。",
			needsKey: true
		};
		return {
			ok: false,
			error: "AI 服務忙碌，請稍後再試。"
		};
	}
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "AI 沒有回傳內容。"
	};
	return {
		ok: true,
		text
	};
}
async function complete(messages, maxTokens, clientKey) {
	const resolved = resolveProvider(clientKey);
	if (!resolved) return {
		ok: false,
		error: "尚未設定 Gemini API 金鑰。請在助教面板貼上金鑰，或於網站後台加入 GEMINI_API_KEY。",
		needsKey: true
	};
	try {
		if (resolved.provider === "gemini") return await completeGemini(resolved.key, messages, maxTokens);
		return await completeXai(resolved.key, messages, maxTokens);
	} catch {
		return {
			ok: false,
			error: "連線逾時，請稍後再試。"
		};
	}
}
var aiStatus_createServerFn_handler = createServerRpc({
	id: "a0f232b5ca0187bc9fe40a301ee2940b0a5db3a672463d1e57d3938a935a6d51",
	name: "aiStatus",
	filename: "src/lib/ai.ts"
}, (opts) => aiStatus.__executeServer(opts));
var aiStatus = createServerFn({ method: "GET" }).handler(aiStatus_createServerFn_handler, async () => {
	return {
		geminiEnv: Boolean(envGeminiKey()),
		xaiEnv: Boolean((process.env.XAI_API_KEY ?? "").trim())
	};
});
var pingAi_createServerFn_handler = createServerRpc({
	id: "f313621e15afa40d27d6fa1834e943da25b305a1ca5a179312e1d50fd18d763a",
	name: "pingAi",
	filename: "src/lib/ai.ts"
}, (opts) => pingAi.__executeServer(opts));
var pingAi = createServerFn({ method: "POST" }).validator((input) => input).handler(pingAi_createServerFn_handler, async ({ data }) => {
	return complete([{
		role: "system",
		content: "只回兩個字：就緒"
	}, {
		role: "user",
		content: "測試連線"
	}], 32, data.geminiKey);
});
var explainQuiz_createServerFn_handler = createServerRpc({
	id: "75b117e63abc8b4576ce0c9a7e13a47b7e82c2a7d4372a679cf61f8f74b85d2d",
	name: "explainQuiz",
	filename: "src/lib/ai.ts"
}, (opts) => explainQuiz.__executeServer(opts));
var explainQuiz = createServerFn({ method: "POST" }).validator((input) => input).handler(explainQuiz_createServerFn_handler, async ({ data }) => {
	const correct = data.options[data.correctIndex] ?? "";
	const picked = data.options[data.pickedIndex] ?? "";
	const wrong = data.pickedIndex !== data.correctIndex;
	return complete([{
		role: "system",
		content: "你是香港文憑試中文科助教，只講十二篇指定範文。用簡潔繁體中文（香港用語）作答。先給結論，再分點解釋。不要使用英文，不要用 emoji。"
	}, {
		role: "user",
		content: [
			`篇章：${data.articleTitle}`,
			`題目：${data.question}`,
			`選項：${data.options.map((opt, i) => `${i + 1}. ${opt}`).join("／")}`,
			`學生選了：${picked}`,
			`正確答案：${correct}`,
			wrong ? "請說明為何學生所選是錯的、正確選項為何對，並補一句相關原文或詞義提醒。120 字內。" : "學生答對了。請用兩句話鞏固這個考點，並補一句易混點。100 字內。"
		].join("\n")
	}], 280, data.geminiKey);
});
var gradeDictation_createServerFn_handler = createServerRpc({
	id: "9992ca6e632ed08aa35eb4a5c98bb5a8aea582a8fd1b2edb64a5ae9dc3049c67",
	name: "gradeDictation",
	filename: "src/lib/ai.ts"
}, (opts) => gradeDictation.__executeServer(opts));
var gradeDictation = createServerFn({ method: "POST" }).validator((input) => input).handler(gradeDictation_createServerFn_handler, async ({ data }) => {
	return complete([{
		role: "system",
		content: "你是文憑試中文默書助教。用繁體中文。允許通假字、異體字的彈性，但關鍵實詞寫錯仍要指出。不要用 emoji。"
	}, {
		role: "user",
		content: [
			`篇章：${data.articleTitle}`,
			`原句：${data.sentence}`,
			`應填：${data.expected.join("、")}`,
			`學生：${data.given.map((item) => item || "（空白）").join("、")}`,
			"請用這種格式回覆：",
			"判定：全對／語意對用字有誤／錯誤",
			"評語：兩句以內，指出哪個字錯、正確寫法、以及這個詞在句中的意思。"
		].join("\n")
	}], 220, data.geminiKey);
});
var tutorChat_createServerFn_handler = createServerRpc({
	id: "aa1f57deb989cb2243ad631467fdd8027270dc7b122a7790d873db1ae77a2d4c",
	name: "tutorChat",
	filename: "src/lib/ai.ts"
}, (opts) => tutorChat.__executeServer(opts));
var tutorChat = createServerFn({ method: "POST" }).validator((input) => input).handler(tutorChat_createServerFn_handler, async ({ data }) => {
	const article = data.articleId ? getArticle(data.articleId) : void 0;
	const context = article ? [
		`學生正在讀：${article.title}（${article.author}）`,
		`核心論點：${article.c.join("；")}`,
		`必考詞：${article.v.map((item) => `${item.w}＝${item.m}`).join("；")}`,
		`原文節錄：${article.p.slice(0, 2).map((para) => para.t).join("").slice(0, 500)}`
	].join("\n") : `指定範文目錄：${TITLES}`;
	const history = data.messages.slice(-8).map((item) => ({
		role: item.role,
		content: item.content.slice(0, 800)
	}));
	return complete([{
		role: "system",
		content: [
			"你是「範文十二式」書齋助教，專責香港 DSE 中文科十二篇指定範文。",
			"用簡潔繁體中文回答：先一句結論，再短點說明。必要時引用原文短句。",
			"不要編造課外原文，不確定就明說。不要用 emoji，不要長篇作文。",
			context
		].join("\n")
	}, ...history], 420, data.geminiKey);
});
var generateQuiz_createServerFn_handler = createServerRpc({
	id: "0c5a06178f3eb2ddaac554a30d244d37cce60e9b6b9ce689aaa01bfd18804e87",
	name: "generateQuiz",
	filename: "src/lib/ai.ts"
}, (opts) => generateQuiz.__executeServer(opts));
var generateQuiz = createServerFn({ method: "POST" }).validator((input) => input).handler(generateQuiz_createServerFn_handler, async ({ data }) => {
	const article = getArticle(data.articleId);
	if (!article) return {
		ok: false,
		error: "找不到這篇範文。"
	};
	const excerpt = article.p.map((para) => para.t).join("\n").slice(0, 1400);
	const result = await complete([{
		role: "system",
		content: "你是 DSE 中文科出題老師。只根據提供的指定範文出題。回覆必須是純 JSON 陣列，不要 markdown。"
	}, {
		role: "user",
		content: [
			`篇章：${article.title}／${article.author}`,
			`論點：${article.c.join("；")}`,
			`詞解：${article.v.map((item) => `${item.w}：${item.m}`).join("；")}`,
			`原文：${excerpt}`,
			"請出 6 題四選一選擇題，覆蓋：詞義、句意、寫作手法、主旨。難度接近 HKDSE。",
			"格式：[{\"q\":\"題幹\",\"o\":[\"A\",\"B\",\"C\",\"D\"],\"a\":0}]",
			"a 是正確選項的 0-based 索引。題幹與選項用繁體中文。"
		].join("\n")
	}], 900, data.geminiKey);
	if (!result.ok) return result;
	try {
		const fenced = result.text.match(/```(?:json)?\s*([\s\S]*?)```/);
		const raw = fenced ? fenced[1] : result.text;
		const start = raw.indexOf("[");
		const end = raw.lastIndexOf("]");
		if (start < 0 || end <= start) return {
			ok: false,
			error: "AI 回傳格式不正確。"
		};
		const parsed = JSON.parse(raw.slice(start, end + 1));
		if (!Array.isArray(parsed)) return {
			ok: false,
			error: "AI 回傳格式不正確。"
		};
		const questions = parsed.map((row) => {
			if (!row || typeof row !== "object") return null;
			const item = row;
			if (typeof item.q !== "string" || !Array.isArray(item.o) || typeof item.a !== "number") return null;
			const options = item.o.filter((opt) => typeof opt === "string").slice(0, 4);
			if (options.length < 4) return null;
			const answer = Math.max(0, Math.min(3, Math.round(item.a)));
			return {
				q: item.q.trim(),
				o: options,
				a: answer
			};
		}).filter((item) => Boolean(item)).slice(0, 6);
		if (questions.length < 4) return {
			ok: false,
			error: "AI 出題數量不足，請再試一次。"
		};
		return {
			ok: true,
			questions
		};
	} catch {
		return {
			ok: false,
			error: "無法解析 AI 出題結果。"
		};
	}
});
//#endregion
export { aiStatus_createServerFn_handler, explainQuiz_createServerFn_handler, generateQuiz_createServerFn_handler, gradeDictation_createServerFn_handler, pingAi_createServerFn_handler, tutorChat_createServerFn_handler };
